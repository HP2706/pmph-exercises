
curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py

/opt/software/python/3.11.3/bin/python get-pip.py

pip install uv
uv pip install triton torch numpy